const state = {
  token: localStorage.getItem("adminToken") || "",
};

document.getElementById("token").value = state.token;
document.getElementById("saveToken").addEventListener("click", () => {
  state.token = document.getElementById("token").value.trim();
  localStorage.setItem("adminToken", state.token);
  alert("Token saved");
});

document.getElementById("createUserForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = new FormData(e.target);
  const payload = {
    username: form.get("username"),
    password: form.get("password"),
    display_name: form.get("display_name"),
    enabled: form.get("enabled") === "on",
    limit_per_sec: Number(form.get("limit_per_sec")),
    limit_per_min: Number(form.get("limit_per_min")),
    limit_per_hour: Number(form.get("limit_per_hour")),
    limit_per_day: Number(form.get("limit_per_day")),
    throttle_ms: Number(form.get("throttle_ms")),
  };
  await api("/api/admin/users", { method: "POST", body: JSON.stringify(payload) });
  e.target.reset();
  await loadUsers();
});

document.getElementById("domainForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = new FormData(e.target);
  const userID = Number(form.get("user_id"));
  const payload = {
    domain: form.get("domain"),
    limit_per_hour: Number(form.get("limit_per_hour")),
    throttle_ms: Number(form.get("throttle_ms")),
  };
  await api(`/api/admin/users/${userID}/domain-throttles`, { method: "PUT", body: JSON.stringify(payload) });
  alert("Domain rule saved");
});

document.getElementById("refreshEvents").addEventListener("click", loadEvents);

async function loadUsers() {
  const users = await api("/api/admin/users");
  const el = document.getElementById("users");
  el.innerHTML = "";
  users.forEach((u) => {
    const node = document.createElement("div");
    node.className = "user-item";
    node.innerHTML = `
      <div><strong>#${u.id}</strong> ${u.username} (${u.display_name || "-"})</div>
      <div>${u.enabled ? '<span class="status-on">ENABLED</span>' : '<span class="status-off">DISABLED</span>'}</div>
      <div>sec:${u.limit_per_sec} min:${u.limit_per_min} hour:${u.limit_per_hour} day:${u.limit_per_day} throttle:${u.throttle_ms}ms</div>
      <div style="margin-top:6px; display:flex; gap:6px;">
        <button data-disable="${u.id}">Disable</button>
        <button data-pass="${u.id}">Reset Password</button>
      </div>
    `;
    el.appendChild(node);
  });

  el.querySelectorAll("button[data-disable]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      await api(`/api/admin/users/${btn.dataset.disable}`, { method: "DELETE" });
      await loadUsers();
    });
  });

  el.querySelectorAll("button[data-pass]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const pass = prompt("New password:");
      if (!pass) return;
      await api(`/api/admin/users/${btn.dataset.pass}/password`, {
        method: "POST",
        body: JSON.stringify({ password: pass }),
      });
      alert("Password updated");
    });
  });
}

async function loadEvents() {
  const userID = document.getElementById("eventsUserId").value;
  const q = userID ? `?user_id=${encodeURIComponent(userID)}&limit=300` : "?limit=300";
  const events = await api(`/api/admin/events${q}`);
  document.getElementById("events").textContent = JSON.stringify(events, null, 2);
}

async function api(url, options = {}) {
  const res = await fetch(url, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      "X-Admin-Token": state.token,
      ...(options.headers || {}),
    },
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || `HTTP ${res.status}`);
  }
  return res.status === 204 ? null : res.json();
}

(async function init() {
  try {
    await loadUsers();
    await loadEvents();
  } catch (e) {
    console.error(e);
  }
})();