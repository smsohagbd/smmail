package repo

import (
	"database/sql"
	"errors"

	"learn/smtp-platform/internal/models"
)

type UserRepo struct {
	db *sql.DB
}

func NewUserRepo(db *sql.DB) *UserRepo { return &UserRepo{db: db} }

func (r *UserRepo) Create(u models.User) (int64, error) {
	res, err := r.db.Exec(`INSERT INTO users
		(username, password_hash, display_name, enabled, limit_per_sec, limit_per_min, limit_per_hour, limit_per_day, throttle_ms)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		u.Username, u.PasswordHash, u.DisplayName, boolToInt(u.Enabled), u.LimitPerSec, u.LimitPerMin, u.LimitPerHour, u.LimitPerDay, u.ThrottleMS)
	if err != nil {
		return 0, err
	}
	return res.LastInsertId()
}

func (r *UserRepo) Update(id int64, u models.User) error {
	_, err := r.db.Exec(`UPDATE users SET
		display_name=?, enabled=?, limit_per_sec=?, limit_per_min=?, limit_per_hour=?, limit_per_day=?, throttle_ms=?, updated_at=CURRENT_TIMESTAMP
		WHERE id=?`,
		u.DisplayName, boolToInt(u.Enabled), u.LimitPerSec, u.LimitPerMin, u.LimitPerHour, u.LimitPerDay, u.ThrottleMS, id)
	return err
}

func (r *UserRepo) SetPassword(id int64, passwordHash string) error {
	_, err := r.db.Exec(`UPDATE users SET password_hash=?, updated_at=CURRENT_TIMESTAMP WHERE id=?`, passwordHash, id)
	return err
}

func (r *UserRepo) GetByUsername(username string) (models.User, error) {
	row := r.db.QueryRow(`SELECT id, username, password_hash, display_name, enabled, limit_per_sec, limit_per_min, limit_per_hour, limit_per_day, throttle_ms, created_at, updated_at
		FROM users WHERE username=?`, username)
	return scanUser(row)
}

func (r *UserRepo) GetByID(id int64) (models.User, error) {
	row := r.db.QueryRow(`SELECT id, username, password_hash, display_name, enabled, limit_per_sec, limit_per_min, limit_per_hour, limit_per_day, throttle_ms, created_at, updated_at
		FROM users WHERE id=?`, id)
	return scanUser(row)
}

func (r *UserRepo) List() ([]models.User, error) {
	rows, err := r.db.Query(`SELECT id, username, password_hash, display_name, enabled, limit_per_sec, limit_per_min, limit_per_hour, limit_per_day, throttle_ms, created_at, updated_at
		FROM users ORDER BY id DESC`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var out []models.User
	for rows.Next() {
		var u models.User
		var enabled int
		if err := rows.Scan(&u.ID, &u.Username, &u.PasswordHash, &u.DisplayName, &enabled, &u.LimitPerSec, &u.LimitPerMin, &u.LimitPerHour, &u.LimitPerDay, &u.ThrottleMS, &u.CreatedAt, &u.UpdatedAt); err != nil {
			return nil, err
		}
		u.Enabled = enabled == 1
		out = append(out, u)
	}
	return out, rows.Err()
}

func (r *UserRepo) Disable(id int64) error {
	_, err := r.db.Exec(`UPDATE users SET enabled=0, updated_at=CURRENT_TIMESTAMP WHERE id=?`, id)
	return err
}

func scanUser(row *sql.Row) (models.User, error) {
	var u models.User
	var enabled int
	if err := row.Scan(&u.ID, &u.Username, &u.PasswordHash, &u.DisplayName, &enabled, &u.LimitPerSec, &u.LimitPerMin, &u.LimitPerHour, &u.LimitPerDay, &u.ThrottleMS, &u.CreatedAt, &u.UpdatedAt); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return u, sql.ErrNoRows
		}
		return u, err
	}
	u.Enabled = enabled == 1
	return u, nil
}

func boolToInt(b bool) int {
	if b {
		return 1
	}
	return 0
}