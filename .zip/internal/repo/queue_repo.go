package repo

import (
	"database/sql"

	"learn/smtp-platform/internal/models"
)

type QueueRepo struct {
	db *sql.DB
}

func NewQueueRepo(db *sql.DB) *QueueRepo { return &QueueRepo{db: db} }

func (r *QueueRepo) Enqueue(item models.QueueItem) error {
	_, err := r.db.Exec(`INSERT INTO outbound_queue (user_id, mail_from, rcpt_to, data, status)
		VALUES (?, ?, ?, ?, 'pending')`, item.UserID, item.MailFrom, item.RcptTo, item.Data)
	return err
}

func (r *QueueRepo) DequeueBatch(n int) ([]models.QueueItem, error) {
	rows, err := r.db.Query(`SELECT id, user_id, mail_from, rcpt_to, data, status, attempts, next_attempt_at, COALESCE(last_error, '')
		FROM outbound_queue
		WHERE status='pending' AND next_attempt_at <= CURRENT_TIMESTAMP
		ORDER BY id ASC LIMIT ?`, n)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var out []models.QueueItem
	for rows.Next() {
		var q models.QueueItem
		if err := rows.Scan(&q.ID, &q.UserID, &q.MailFrom, &q.RcptTo, &q.Data, &q.Status, &q.Attempts, &q.NextAttemptAt, &q.LastError); err != nil {
			return nil, err
		}
		out = append(out, q)
	}
	return out, rows.Err()
}

func (r *QueueRepo) MarkSent(id int64) error {
	_, err := r.db.Exec(`UPDATE outbound_queue SET status='sent', updated_at=CURRENT_TIMESTAMP WHERE id=?`, id)
	return err
}

func (r *QueueRepo) MarkRetry(id int64, errMsg string) error {
	_, err := r.db.Exec(`UPDATE outbound_queue SET attempts=attempts+1, last_error=?, next_attempt_at=DATETIME('now', '+30 seconds'), updated_at=CURRENT_TIMESTAMP WHERE id=?`, errMsg, id)
	return err
}

func (r *QueueRepo) MarkFailed(id int64, errMsg string) error {
	_, err := r.db.Exec(`UPDATE outbound_queue SET status='failed', attempts=attempts+1, last_error=?, updated_at=CURRENT_TIMESTAMP WHERE id=?`, errMsg, id)
	return err
}