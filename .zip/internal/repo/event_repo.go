package repo

import (
	"database/sql"

	"learn/smtp-platform/internal/models"
)

type MailEventRepo struct {
	db *sql.DB
}

func NewMailEventRepo(db *sql.DB) *MailEventRepo { return &MailEventRepo{db: db} }

func (r *MailEventRepo) Create(e models.MailEvent) error {
	_, err := r.db.Exec(`INSERT INTO mail_events (user_id, mail_from, rcpt_to, domain, status, reason)
		VALUES (?, ?, ?, ?, ?, ?)`,
		e.UserID, e.MailFrom, e.RcptTo, e.Domain, e.Status, e.Reason)
	return err
}

func (r *MailEventRepo) List(limit int, userID int64) ([]models.MailEvent, error) {
	query := `SELECT id, user_id, mail_from, rcpt_to, domain, status, COALESCE(reason, ''), created_at FROM mail_events`
	args := []any{}
	if userID > 0 {
		query += ` WHERE user_id=?`
		args = append(args, userID)
	}
	query += ` ORDER BY id DESC LIMIT ?`
	args = append(args, limit)

	rows, err := r.db.Query(query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var out []models.MailEvent
	for rows.Next() {
		var e models.MailEvent
		if err := rows.Scan(&e.ID, &e.UserID, &e.MailFrom, &e.RcptTo, &e.Domain, &e.Status, &e.Reason, &e.CreatedAt); err != nil {
			return nil, err
		}
		out = append(out, e)
	}
	return out, rows.Err()
}