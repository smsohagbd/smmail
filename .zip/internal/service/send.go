package service

import (
	"fmt"
	"strings"

	"learn/smtp-platform/internal/models"
	"learn/smtp-platform/internal/repo"
)

type SendService struct {
	users   *repo.UserRepo
	domains *repo.DomainThrottleRepo
	events  *repo.MailEventRepo
	queue   *repo.QueueRepo
	limiter *Limiter
}

func NewSendService(users *repo.UserRepo, domains *repo.DomainThrottleRepo, events *repo.MailEventRepo, queue *repo.QueueRepo, limiter *Limiter) *SendService {
	return &SendService{users: users, domains: domains, events: events, queue: queue, limiter: limiter}
}

func (s *SendService) HandleMail(user models.User, from string, to []string, data []byte) error {
	for _, rcpt := range to {
		domain := extractDomain(rcpt)
		if domain == "" {
			s.events.Create(models.MailEvent{UserID: user.ID, MailFrom: from, RcptTo: rcpt, Domain: "", Status: "rejected", Reason: "invalid recipient domain"})
			return fmt.Errorf("invalid recipient %s", rcpt)
		}

		domainRule, err := s.domains.Get(user.ID, domain)
		domainLimit := 0
		domainThrottle := 0
		if err == nil {
			domainLimit = domainRule.LimitPerHour
			domainThrottle = domainRule.ThrottleMS
		}

		if err := s.limiter.CheckAndInc(user.ID, domain, user.LimitPerSec, user.LimitPerMin, user.LimitPerHour, user.LimitPerDay, user.ThrottleMS, domainLimit, domainThrottle); err != nil {
			s.events.Create(models.MailEvent{UserID: user.ID, MailFrom: from, RcptTo: rcpt, Domain: domain, Status: "rejected", Reason: err.Error()})
			return err
		}

		if err := s.queue.Enqueue(models.QueueItem{UserID: user.ID, MailFrom: from, RcptTo: rcpt, Data: data}); err != nil {
			s.events.Create(models.MailEvent{UserID: user.ID, MailFrom: from, RcptTo: rcpt, Domain: domain, Status: "failed", Reason: "queue insert failed"})
			return err
		}

		s.events.Create(models.MailEvent{UserID: user.ID, MailFrom: from, RcptTo: rcpt, Domain: domain, Status: "queued", Reason: ""})
	}
	return nil
}

func extractDomain(addr string) string {
	parts := strings.Split(strings.TrimSpace(addr), "@")
	if len(parts) != 2 {
		return ""
	}
	return strings.ToLower(parts[1])
}