package service

import (
	"context"
	"fmt"
	"net/smtp"
	"time"

	"learn/smtp-platform/internal/config"
	"learn/smtp-platform/internal/models"
	"learn/smtp-platform/internal/repo"
)

type DeliveryService struct {
	cfg   config.Config
	queue *repo.QueueRepo
	event *repo.MailEventRepo
}

func NewDeliveryService(cfg config.Config, queue *repo.QueueRepo, event *repo.MailEventRepo) *DeliveryService {
	return &DeliveryService{cfg: cfg, queue: queue, event: event}
}

func (s *DeliveryService) Run(ctx context.Context) {
	ticker := time.NewTicker(2 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			s.process()
		}
	}
}

func (s *DeliveryService) process() {
	items, err := s.queue.DequeueBatch(30)
	if err != nil {
		return
	}
	for _, item := range items {
		if err := s.deliver(item); err != nil {
			if item.Attempts >= 4 {
				_ = s.queue.MarkFailed(item.ID, err.Error())
				_ = s.event.Create(models.MailEvent{UserID: item.UserID, MailFrom: item.MailFrom, RcptTo: item.RcptTo, Domain: extractDomain(item.RcptTo), Status: "failed", Reason: err.Error()})
			} else {
				_ = s.queue.MarkRetry(item.ID, err.Error())
			}
			continue
		}

		_ = s.queue.MarkSent(item.ID)
		_ = s.event.Create(models.MailEvent{UserID: item.UserID, MailFrom: item.MailFrom, RcptTo: item.RcptTo, Domain: extractDomain(item.RcptTo), Status: "sent", Reason: ""})
	}
}

func (s *DeliveryService) deliver(item models.QueueItem) error {
	if s.cfg.UpstreamSMTPHost == "" {
		// Local dev mode: pretend delivery succeeded.
		return nil
	}

	addr := fmt.Sprintf("%s:%s", s.cfg.UpstreamSMTPHost, s.cfg.UpstreamSMTPPort)
	auth := smtp.PlainAuth("", s.cfg.UpstreamSMTPUser, s.cfg.UpstreamSMTPPass, s.cfg.UpstreamSMTPHost)
	from := item.MailFrom
	if s.cfg.UpstreamMailFrom != "" {
		from = s.cfg.UpstreamMailFrom
	}
	return smtp.SendMail(addr, auth, from, []string{item.RcptTo}, item.Data)
}