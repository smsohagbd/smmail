package httpapi

import (
	"fmt"
	"net/http"
	"net/smtp"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
	"learn/smtp-platform/internal/config"
	"learn/smtp-platform/internal/models"
	"learn/smtp-platform/internal/repo"
	"learn/smtp-platform/internal/service"
)

type Handler struct {
	cfg     config.Config
	users   *repo.UserRepo
	domains *repo.DomainThrottleRepo
	events  *repo.MailEventRepo
}

func NewHandler(cfg config.Config, users *repo.UserRepo, domains *repo.DomainThrottleRepo, events *repo.MailEventRepo) *Handler {
	return &Handler{cfg: cfg, users: users, domains: domains, events: events}
}

func (h *Handler) Router() *gin.Engine {
	r := gin.Default()
	r.Static("/ui", "web/ui")
	r.GET("/", func(c *gin.Context) { c.Redirect(http.StatusFound, "/ui/index.html") })

	api := r.Group("/api/admin", h.adminAuth())
	api.GET("/users", h.listUsers)
	api.POST("/users", h.createUser)
	api.PUT("/users/:id", h.updateUser)
	api.POST("/users/:id/password", h.setPassword)
	api.DELETE("/users/:id", h.disableUser)

	api.GET("/users/:id/domain-throttles", h.listDomainThrottles)
	api.PUT("/users/:id/domain-throttles", h.upsertDomainThrottle)

	api.GET("/events", h.listEvents)
	api.POST("/smtp-test", h.smtpTest)

	return r
}

func (h *Handler) adminAuth() gin.HandlerFunc {
	return func(c *gin.Context) {
		token := c.GetHeader("X-Admin-Token")
		if token == "" || token != h.cfg.AdminToken {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "unauthorized"})
			return
		}
		c.Next()
	}
}

type createUserReq struct {
	Username     string `json:"username" binding:"required"`
	Password     string `json:"password"`
	DisplayName  string `json:"display_name"`
	Enabled      bool   `json:"enabled"`
	LimitPerSec  int    `json:"limit_per_sec"`
	LimitPerMin  int    `json:"limit_per_min"`
	LimitPerHour int    `json:"limit_per_hour"`
	LimitPerDay  int    `json:"limit_per_day"`
	ThrottleMS   int    `json:"throttle_ms"`
}

func (h *Handler) createUser(c *gin.Context) {
	var req createUserReq
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	if req.Password == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "password is required"})
		return
	}

	hash, err := service.HashPassword(req.Password)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "password hash failed"})
		return
	}

	u := models.User{
		Username:     req.Username,
		PasswordHash: hash,
		DisplayName:  req.DisplayName,
		Enabled:      req.Enabled,
		LimitPerSec:  defaultIfZero(req.LimitPerSec, 5),
		LimitPerMin:  defaultIfZero(req.LimitPerMin, 120),
		LimitPerHour: defaultIfZero(req.LimitPerHour, 3000),
		LimitPerDay:  defaultIfZero(req.LimitPerDay, 20000),
		ThrottleMS:   req.ThrottleMS,
	}
	id, err := h.users.Create(u)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusCreated, gin.H{"id": id})
}

func (h *Handler) listUsers(c *gin.Context) {
	users, err := h.users.List()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, users)
}

func (h *Handler) updateUser(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}
	var req createUserReq
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	err = h.users.Update(id, models.User{
		DisplayName:  req.DisplayName,
		Enabled:      req.Enabled,
		LimitPerSec:  defaultIfZero(req.LimitPerSec, 5),
		LimitPerMin:  defaultIfZero(req.LimitPerMin, 120),
		LimitPerHour: defaultIfZero(req.LimitPerHour, 3000),
		LimitPerDay:  defaultIfZero(req.LimitPerDay, 20000),
		ThrottleMS:   req.ThrottleMS,
	})
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"ok": true})
}

func (h *Handler) setPassword(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}
	var req struct {
		Password string `json:"password" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	hash, err := service.HashPassword(req.Password)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "password hash failed"})
		return
	}
	if err := h.users.SetPassword(id, hash); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"ok": true})
}

func (h *Handler) disableUser(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}
	if err := h.users.Disable(id); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"ok": true})
}

func (h *Handler) listDomainThrottles(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid user id"})
		return
	}
	items, err := h.domains.ListByUser(id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, items)
}

func (h *Handler) upsertDomainThrottle(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid user id"})
		return
	}
	var req struct {
		Domain       string `json:"domain" binding:"required"`
		LimitPerHour int    `json:"limit_per_hour"`
		ThrottleMS   int    `json:"throttle_ms"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	if err := h.domains.Upsert(id, req.Domain, defaultIfZero(req.LimitPerHour, 1000), req.ThrottleMS); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"ok": true})
}

func (h *Handler) listEvents(c *gin.Context) {
	limit := parseInt(c.Query("limit"), 200)
	userID := int64(parseInt(c.Query("user_id"), 0))
	items, err := h.events.List(limit, userID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, items)
}

func (h *Handler) smtpTest(c *gin.Context) {
	var req struct {
		Host     string `json:"host" binding:"required"`
		Port     int    `json:"port"`
		Username string `json:"username"`
		Password string `json:"password"`
		From     string `json:"from" binding:"required"`
		To       string `json:"to" binding:"required"`
		Subject  string `json:"subject"`
		Body     string `json:"body"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	port := req.Port
	if port == 0 {
		port = 25
	}

	recipients := splitRecipients(req.To)
	if len(recipients) == 0 {
		c.JSON(http.StatusBadRequest, gin.H{"error": "at least one recipient is required"})
		return
	}

	addr := fmt.Sprintf("%s:%d", req.Host, port)
	msg := []byte("From: " + req.From + "\r\n" +
		"To: " + strings.Join(recipients, ",") + "\r\n" +
		"Subject: " + req.Subject + "\r\n" +
		"MIME-Version: 1.0\r\n" +
		"Content-Type: text/plain; charset=UTF-8\r\n\r\n" +
		req.Body + "\r\n")

	var auth smtp.Auth
	if req.Username != "" {
		auth = smtp.PlainAuth("", req.Username, req.Password, req.Host)
	}

	if err := smtp.SendMail(addr, auth, req.From, recipients, msg); err != nil {
		c.JSON(http.StatusBadGateway, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"ok": true, "message": "test email sent"})
}

func splitRecipients(raw string) []string {
	raw = strings.ReplaceAll(raw, "\n", ",")
	raw = strings.ReplaceAll(raw, ";", ",")
	parts := strings.Split(raw, ",")
	out := make([]string, 0, len(parts))
	for _, p := range parts {
		p = strings.TrimSpace(p)
		if p != "" {
			out = append(out, p)
		}
	}
	return out
}

func parseInt(v string, fallback int) int {
	x, err := strconv.Atoi(v)
	if err != nil {
		return fallback
	}
	return x
}

func defaultIfZero(v, fallback int) int {
	if v == 0 {
		return fallback
	}
	return v
}