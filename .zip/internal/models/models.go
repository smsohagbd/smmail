package models

import "time"

type User struct {
	ID           int64     `json:"id"`
	Username     string    `json:"username"`
	PasswordHash string    `json:"-"`
	DisplayName  string    `json:"display_name"`
	Enabled      bool      `json:"enabled"`
	LimitPerSec  int       `json:"limit_per_sec"`
	LimitPerMin  int       `json:"limit_per_min"`
	LimitPerHour int       `json:"limit_per_hour"`
	LimitPerDay  int       `json:"limit_per_day"`
	ThrottleMS   int       `json:"throttle_ms"`
	CreatedAt    time.Time `json:"created_at"`
	UpdatedAt    time.Time `json:"updated_at"`
}

type DomainThrottle struct {
	ID           int64     `json:"id"`
	UserID       int64     `json:"user_id"`
	Domain       string    `json:"domain"`
	LimitPerHour int       `json:"limit_per_hour"`
	ThrottleMS   int       `json:"throttle_ms"`
	CreatedAt    time.Time `json:"created_at"`
	UpdatedAt    time.Time `json:"updated_at"`
}

type MailEvent struct {
	ID        int64     `json:"id"`
	UserID    int64     `json:"user_id"`
	MailFrom  string    `json:"mail_from"`
	RcptTo    string    `json:"rcpt_to"`
	Domain    string    `json:"domain"`
	Status    string    `json:"status"`
	Reason    string    `json:"reason"`
	CreatedAt time.Time `json:"created_at"`
}

type QueueItem struct {
	ID            int64
	UserID        int64
	MailFrom      string
	RcptTo        string
	Data          []byte
	Status        string
	Attempts      int
	NextAttemptAt time.Time
	LastError     string
}