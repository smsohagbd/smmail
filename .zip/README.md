# Go SMTP Platform (Postfix-like control plane)

Features implemented:
- SMTP AUTH (PLAIN and LOGIN)
- Per-user rate limits: per-second, per-minute, per-hour, per-day
- Per-user throttling (minimum milliseconds between sends)
- Per-domain throttling and per-domain hourly limit per user
- Outbound queue + delivery worker + retry/fail logic
- Admin API to create/manage users and limits
- Admin dashboard for account, throttle, and event operations

## Run

1. Install Go 1.22+
2. Copy `.env.example` values into your environment
3. Fetch deps:
   - `go mod tidy`
4. Start server:
   - `go run ./cmd/smtpd`

Admin UI:
- `http://localhost:8080/ui/index.html`

SMTP:
- `localhost:2525`

## Admin API token
Set header on every request:
- `X-Admin-Token: <ADMIN_TOKEN>`

## Important
This is a strong base, not a complete replacement for Postfix. For production internet sending, add:
- DKIM signing
- SPF/DMARC alignment and bounce processing
- Queue sharding + persistent distributed rate-limiter
- TLS cert management and forced TLS policies
- Abuse detection and IP/domain reputation controls
## Local SMTP test with username/password

1. Edit `smtp-test.local.json` and set:
   - `smtp_username`, `smtp_password`
   - `from`, `to`
2. Run:
   - `powershell -ExecutionPolicy Bypass -File .\scripts\send-test.ps1`
3. If your config file has another name/path:
   - `powershell -ExecutionPolicy Bypass -File .\scripts\send-test.ps1 -ConfigPath .\my-config.json`

If auth fails, first create the SMTP user in admin dashboard/API, then retry.
